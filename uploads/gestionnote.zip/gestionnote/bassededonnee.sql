-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:8889
-- Généré le : ven. 05 jan. 2024 à 01:03
-- Version du serveur : 5.7.39
-- Version de PHP : 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `DB`
--

-- --------------------------------------------------------

--
-- Structure de la table `Etudiant`
--

CREATE TABLE `Etudiant` (
  `id` int(11) NOT NULL,
  `NumEtudiant` int(12) NOT NULL,
  `Nom` varchar(30) NOT NULL,
  `Prenom` varchar(30) NOT NULL,
  `Adresse` varchar(255) DEFAULT 'ValeurParDefaut',
  `email` varchar(30) NOT NULL,
  `Moyenne` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `Matiere`
--

CREATE TABLE `Matiere` (
  `id_mat` int(11) NOT NULL,
  `intituler` varchar(20) NOT NULL,
  `coef` int(11) NOT NULL,
  `note` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `Matiere`
--

INSERT INTO `Matiere` (`id_mat`, `intituler`, `coef`, `note`) VALUES
(105, 'participation', 1, ''),
(106, 'partiel', 2, ''),
(107, 'participation', 1, ''),
(108, 'partiel', 2, ''),
(109, 'participation', 1, ''),
(110, 'partiel', 2, ''),
(111, 'participation', 1, ''),
(112, 'partiel', 2, ''),
(113, 'participation', 1, ''),
(114, 'partiel', 2, ''),
(115, 'participation', 1, ''),
(116, 'partiel', 2, ''),
(117, 'participation', 1, ''),
(118, 'partiel', 2, ''),
(119, 'participation', 1, ''),
(120, 'partiel', 2, ''),
(121, 'participation', 1, ''),
(122, 'partiel', 2, ''),
(123, 'participation', 1, ''),
(124, 'partiel', 2, ''),
(125, 'participation', 1, ''),
(126, 'partiel', 2, ''),
(127, 'participation', 1, ''),
(128, 'partiel', 2, ''),
(129, 'participation', 1, ''),
(130, 'partiel', 2, ''),
(131, 'participation', 1, ''),
(132, 'partiel', 2, ''),
(133, 'participation', 1, ''),
(134, 'partiel', 2, ''),
(135, 'participation', 1, ''),
(136, 'partiel', 2, ''),
(137, 'participation', 1, ''),
(138, 'partiel', 2, ''),
(139, 'participation', 1, ''),
(140, 'partiel', 2, ''),
(141, 'participation', 1, ''),
(142, 'partiel', 2, ''),
(143, 'participation', 1, ''),
(144, 'partiel', 2, ''),
(145, 'participation', 1, ''),
(146, 'partiel', 2, ''),
(147, 'participation', 1, ''),
(148, 'partiel', 2, ''),
(149, 'participation', 1, ''),
(150, 'partiel', 2, ''),
(151, 'participation', 1, ''),
(152, 'partiel', 2, ''),
(153, 'participation', 1, ''),
(154, 'partiel', 2, ''),
(155, 'participation', 1, ''),
(156, 'partiel', 2, ''),
(157, 'participation', 1, ''),
(158, 'partiel', 2, ''),
(159, 'minichat', 2, ''),
(160, 'ent', 5, ''),
(161, 'participation', 5, ''),
(162, 'partiel', 2, ''),
(163, 'minichat', 2, ''),
(164, 'reseau', 2, ''),
(165, 'participation', 5, ''),
(166, 'partiel', 2, ''),
(167, 'minichat', 2, ''),
(168, 'reseau', 2, ''),
(169, 'participation', 5, ''),
(170, 'partiel', 2, ''),
(188, 'reseau', 2, ''),
(189, 'participation', 5, ''),
(190, 'partiel', 2, ''),
(191, 'minichat', 2, ''),
(192, 'reseau', 2, ''),
(193, 'participation', 5, ''),
(194, 'partiel', 2, ''),
(195, 'minichat', 2, ''),
(196, 'reseau', 2, ''),
(197, 'participation', 5, ''),
(199, 'minichat', 2, ''),
(200, 'reseau', 2, ''),
(201, 'participation', 5, ''),
(202, 'partiel', 2, ''),
(203, 'minichat', 2, ''),
(204, 'reseau', 2, ''),
(205, 'participation', 5, ''),
(206, 'partiel', 2, ''),
(207, 'minichat', 2, ''),
(208, 'reseau', 2, ''),
(209, 'participation', 5, ''),
(210, 'partiel', 2, ''),
(211, 'minichat', 2, ''),
(212, 'reseau', 2, ''),
(213, 'participation', 5, ''),
(214, 'partiel', 2, ''),
(215, 'minichat', 2, ''),
(216, 'reseau', 2, ''),
(217, 'participation', 5, ''),
(218, 'partiel', 2, ''),
(219, 'minichat', 2, ''),
(220, 'reseau', 2, ''),
(221, 'participation', 5, ''),
(222, 'partiel', 2, ''),
(223, 'minichat', 2, ''),
(224, 'reseau', 2, ''),
(225, 'participation', 5, ''),
(226, 'partiel', 2, ''),
(227, 'minichat', 2, ''),
(228, 'reseau', 2, ''),
(229, 'participation', 5, ''),
(230, 'partiel', 2, ''),
(231, 'minichat', 2, ''),
(232, 'reseau', 2, ''),
(233, 'participation', 7, ''),
(234, 'partiel', 9, ''),
(235, 'minichat', 2, ''),
(236, 'reseau', 9, ''),
(237, 'participation', 7, ''),
(244, 'reseau', 13, ''),
(245, 'participation', 7, ''),
(246, 'partiel', 9, ''),
(247, 'minichat', 2, ''),
(248, 'reseau', 13, ''),
(249, 'participation', 7, ''),
(250, 'partiel', 9, ''),
(251, 'minichat', 2, ''),
(252, 'reseau', 13, ''),
(253, 'participation', 7, ''),
(254, 'partiel', 9, ''),
(255, 'minichat', 2, ''),
(256, 'reseau', 13, ''),
(257, 'participation', 7, ''),
(258, 'partiel', 9, ''),
(259, 'minichat', 2, ''),
(260, 'reseau', 13, ''),
(261, 'participation', 7, ''),
(262, 'partiel', 9, ''),
(263, 'minichat', 2, ''),
(264, 'reseau', 13, ''),
(265, 'participation', 7, ''),
(266, 'partiel', 9, ''),
(267, 'minichat', 2, ''),
(268, 'reseau', 13, ''),
(269, 'participation', 7, ''),
(270, 'partiel', 9, ''),
(271, 'minichat', 2, ''),
(272, 'reseau', 13, ''),
(273, 'participation', 7, ''),
(274, 'partiel', 9, ''),
(275, 'minichat', 2, ''),
(276, 'reseau', 13, ''),
(277, 'participation', 7, ''),
(278, 'partiel', 9, ''),
(279, 'minichat', 2, ''),
(280, 'reseau', 13, ''),
(281, 'participation', 7, ''),
(282, 'partiel', 9, ''),
(283, 'minichat', 2, ''),
(284, 'reseau', 13, ''),
(285, 'participation', 7, ''),
(286, 'partiel', 9, ''),
(287, 'minichat', 2, ''),
(288, 'reseau', 13, ''),
(289, 'participation', 7, ''),
(290, 'partiel', 9, ''),
(291, 'minichat', 2, ''),
(292, 'reseau', 56, ''),
(293, 'participation', 7, ''),
(294, 'partiel', 9, ''),
(295, 'minichat', 2, ''),
(296, 'reseau', 56, ''),
(297, 'participation', 7, ''),
(298, 'partiel', 9, ''),
(299, 'minichat', 2, ''),
(300, 'reseau', 56, ''),
(301, 'participation', 7, ''),
(302, 'partiel', 9, ''),
(303, 'minichat', 2, ''),
(304, 'reseau', 56, ''),
(305, 'participation', 7, ''),
(306, 'partiel', 9, ''),
(307, 'minichat', 2, ''),
(308, 'reseau', 56, ''),
(309, 'participation', 7, ''),
(310, 'partiel', 9, ''),
(311, 'minichat', 2, ''),
(312, 'reseau', 56, ''),
(313, 'participation', 7, ''),
(314, 'partiel', 9, ''),
(315, 'minichat', 2, ''),
(316, 'reseau', 56, ''),
(317, 'participation', 7, ''),
(318, 'partiel', 9, ''),
(319, 'minichat', 2, ''),
(320, 'reseau', 56, ''),
(321, 'participation', 7, ''),
(329, 'participation', 7, ''),
(330, 'partiel', 9, ''),
(331, 'minichat', 2, ''),
(332, 'reseau', 56, ''),
(333, 'participation', 7, ''),
(335, 'minichat', 2, ''),
(337, 'participation', 1, '8'),
(338, 'anglais', 7, '3'),
(339, 'ui ux designer', 16, '12'),
(340, 'ent', 9, '10'),
(341, 'participation', 1, '8'),
(342, 'anglais', 7, '3'),
(343, 'ui ux designer', 16, '12'),
(344, 'ent', 9, '10');

-- --------------------------------------------------------

--
-- Structure de la table `Note`
--

CREATE TABLE `Note` (
  `id_note` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `valeur` int(11) NOT NULL,
  `intmatiere` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `Etudiant`
--
ALTER TABLE `Etudiant`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `Matiere`
--
ALTER TABLE `Matiere`
  ADD PRIMARY KEY (`id_mat`);

--
-- Index pour la table `Note`
--
ALTER TABLE `Note`
  ADD PRIMARY KEY (`id_note`),
  ADD KEY `id` (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `Etudiant`
--
ALTER TABLE `Etudiant`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `Matiere`
--
ALTER TABLE `Matiere`
  MODIFY `id_mat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=345;

--
-- AUTO_INCREMENT pour la table `Note`
--
ALTER TABLE `Note`
  MODIFY `id_note` int(11) NOT NULL AUTO_INCREMENT;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `Note`
--
ALTER TABLE `Note`
  ADD CONSTRAINT `Note_ibfk_1` FOREIGN KEY (`id`) REFERENCES `etudiant` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
