<?php

  include("includes/db.php");
  
  
?>

<!--formulaire entrée des notes -->
<div class="container">

                
             <form id="myForm" method="POST" action="moyenne.php">
                <div class="form-row" id="divetudiant">

                           <div class="form-group col-md-2">
                                  <label class="control-label">N° Etudiant <?php echo $NUMETUD; ?>:</label>
                                </div>
                           <div class="form-group col-md-10">
                                 <input type="text" class="form-control col-sm-6" id="numetd" rows="2" name="numetd"
                                placeholder="N° Etudiant" required/>
                                
                           </div> 
                           
                           <div class="form-group col-md-2">
                                  <label class="control-label">Nom <?php echo $NOM; ?>:</label>
                                </div>
                           <div class="form-group col-md-10">
                                 <input type="text" class="form-control col-sm-6" id="nom" rows="2" name="nom"
                                placeholder="Almeida Gomes" required/>
                                
                           </div>   
                           
                           <div class="form-group col-md-2">
                                  <label class="control-label">PRENOM <?php echo $PRENOM; ?>:</label>
                                </div>
                           <div class="form-group col-md-10">
                                 <input type="text" class="form-control col-sm-6" id="prenom" rows="2" name="prenom"
                                placeholder="Tania" required/>
                                
                           </div>      
                </div>
                </div>
                </div>
                <div class="form-row" id="divMatiere1">

                           <div class="form-group col-md-2">
                                  <label class="control-label">participation:</label>
                                </div>
                           <div class="form-group col-md-3">
                                 <input type="text" class="form-control col-sm-6" id="matiere1" rows="2" name="matiere1"
                                placeholder="ds 1" required/>
                           </div>
                           <div class="form-group col-md-3">
                                 <input type="text" class="form-control col-sm-3" id="coef1" rows="2" name="coef1"
                                placeholder="Coef" required/>
                           </div>
                           <div class="form-group col-md-3">
                                 <input type="note" class="form-control col-sm-3" id="note1" rows="2" name="note1" 
                                placeholder="La note " required/>
                           </div>
                                
                              

                </div>
                <div class="form-row" id="divMatiere2">

                           <div class="form-group col-md-2">
                                  <label class="control-label">Partiel php:</label>
                                </div>
                           <div class="form-group col-md-3">
                                 <input type="text" class="form-control col-sm-6" id="matiere2" rows="2" name="matiere2"
                                placeholder="ds 2" required/>
                           </div>
                           <div class="form-group col-md-3">
                                 <input type="text" class="form-control col-sm-3" id="coef2" rows="2" name="coef2"
                                placeholder="Coef" required/>
                           </div>
                           <div class="form-group col-md-3">
                                 <input type="note" class="form-control col-sm-3" id="note2" rows="2" name="note2"
                                placeholder="La note " required/>
                           </div>
                 </div>
                              
                    
                <div class="form-row" id="divMatiere3">

                           <div class="form-group col-md-2">
                                  <label class="control-label">mini chat:</label>
                                </div>
                           <div class="form-group col-md-3">
                                 <input type="text" class="form-control col-sm-6" id="matiere3" rows="2" name="matiere3"
                                placeholder="ds 3" required/>
                           </div>
                           <div class="form-group col-md-3">
                                 <input type="text" class="form-control col-sm-3" id="coef3" rows="2" name="coef3"
                                placeholder="Coef" required/>
                           </div>
                           <div class="form-group col-md-3">
                                 <input type="note" class="form-control col-sm-3" id="note3" rows="2" name="note3"
                                placeholder="La note" required/>
                           </div>
                </div>
                              
                    
                <div class="form-row" id="divMatiere4">

                           <div class="form-group col-md-2">
                                  <label class="control-label">ENT:</label>
                                </div>
                           <div class="form-group col-md-3">
                                 <input type="text" class="form-control col-sm-6" id="matiere4 " rows="2" name="matiere4"
                                placeholder="ds 4" required/>
                           </div>
                           <div class="form-group col-md-3">
                                 <input type="text" class="form-control col-sm-3" id="coef4" rows="2" name="coef4"
                                placeholder="Coef" required/>
                           </div>
                           <div class="form-group col-md-3">
                                 <input type="note" class="form-control col-sm-3" id="note4" rows="2" name="note4"
                                placeholder="La note" required/>
                           </div>
                              
                              
                </div>
               
                <input type="submit" name="submit" value="Calculer">

                
            </form>
            <?php
if (isset($_POST['submit'])) {
    header("Location: moyenne.php");
    exit;
}
?>

</div>








</body>
</html>