<?php
  include("includes/connexion.php");

    
?>

<div class="container">
 
 <h1>Veuillez Saisir vous notes et matiere </h1>   
 <br>

<?php
 include("Formulaire.php");
 if (isset($_POST['submit'])){   header("moyenne.php");   }
 ?>



	


</div><






</body>
</html>




