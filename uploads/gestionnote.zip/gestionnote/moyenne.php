<?php

  include("includes/db.php");
  


//récupèrent la valeur du champ de formulaire ayant pour nom 'numetd' à partir de la méthode POST et la stockent dans la variable $NUMETUD. Ensuite, elles convertissent cette valeur en un entier en utilisant la conversion de type (int) et la stockent dans la variable $INTNUMETUD.

$NUMETUD = $_POST['numetd'];
$INTNUMETUD = (int)$NUMETUD;

$NOM = $_POST['nom'];
$PRENOM = $_POST['prenom'];



//la declaration des variables utiliser pour stocker les notes, matieres, coef
$MAT1 = $_POST['matiere1'];
$COF1 = $_POST['coef1'];
$INTCOF1 = (int)$COF1;
$NOTE1 = (is_int($_POST['note1']) ? (int)$_POST['note1'] : (float)($_POST['note1']));


$MAT2 = $_POST['matiere2'];
$COF2 = $_POST['coef2'];
$INTCOF2 = (int)$COF2;
$NOTE2 = (is_int($_POST['note2']) ? (int)$_POST['note2'] : (float)($_POST['note2']));

$MAT3 = $_POST['matiere3'];
$COF3 = $_POST['coef3'];
$INTCOF3 = (int)$COF2;
$NOTE3 = (is_int($_POST['note3']) ? (int)$_POST['note3'] : (float)($_POST['note3']));

$MAT4 = $_POST['matiere4'];
$COF4 = $_POST['coef4'];
$INTCOF4 = (int)$COF4;
$NOTE4 = (is_int($_POST['note4']) ? (int)$_POST['note4'] : (float)($_POST['note4']));



$TOTAL = (($INTCOF1 * $NOTE1) + ($INTCOF2 * $NOTE2) + ($INTCOF3 * $NOTE3) + ($INTCOF4 * $NOTE4));
$MOYGENERAL = ($TOTAL / ($INTCOF1 + $INTCOF2 + $INTCOF3 + $INTCOF4 ));





//une requête d'insertion destinée à ajouter des données dans une table appelée "Matiere" avec deux colonnes : "intituler" et "coef". Les valeurs à insérer sont définies dans les variables $MAT1, $COF1, $MAT2, $COF2, $MAT3, $COF3, $MAT4 et $COF4.

$sql = "INSERT INTO Matiere (intituler, coef,note) 
           VALUES ('$MAT1','$COF1','$NOTE1'),
                  ('$MAT2','$COF2','$NOTE2'),
                  ('$MAT3','$COF3', '$NOTE3'),
                  ('$MAT4','$COF4','$NOTE4')";
// Supposons que $conn soit votre connexion à la base de données



$sql = "INSERT INTO VotreTable (Nom, Prenom, Moyenne) 
        VALUES ('$NOM', '$PRENOM', 8.45)";









$result = mysqli_query($conn, $sql);

if ($result) {
    echo "La requête a été exécutée avec succès.";
} else {
    echo "Erreur lors de l'exécution de la requête : " . mysqli_error($conn);
}









  
$conn->close();
?>




<h1>Moyenne</h1>
<br>
<div class="form-row" id="divetudiant">

                           <div class="form-group col-md-4">
                                  <label class="control-label">Nom :  <?php echo $NOM; ?></label>
                                </div>
                          <div class="form-group col-md-4">
                                  <label class="control-label">Prénom :  <?php echo $PRENOM; ?></label>
                                </div>
                          <div class="form-group col-md-4">
                                  <label class="control-label">N° Etudiant :  <?php echo $INTNUMETUD; ?></label>
                                </div>
                                
                           </div>      
                </div>
<br>
<table style="width:100%">
  <tr>
    <th>Matiere</th>
    <th>Coefficiant</th> 
    <th>Note</th>
  </tr>
  <tr>
    <td><?php echo $MAT1; ?> </td>
    <td><?php echo $INTCOF1; ?></td>
    <td><?php echo $NOTE1; ?></td>
  </tr>
   <tr>
    <td><?php echo $MAT2; ?> </td>
    <td><?php echo $INTCOF2; ?></td>
    <td><?php echo $NOTE2; ?></td>
  </tr>
   <tr>
    <td><?php echo $MAT3; ?> </td>
    <td><?php echo $INTCOF3; ?></td>
    <td><?php echo $NOTE3; ?></td>
  </tr>
   <tr>
    <td><?php echo $MAT4; ?> </td>
    <td><?php echo $INTCOF4; ?></td>
    <td><?php echo $NOTE4; ?></td>
  </tr>
   
</table>
<br>

<!--Ce code PHP affiche le statut d'admission en fonction de la valeur de la variable $MOYGENERAL. Si la valeur de $MOYGENERAL est supérieure ou égale à 10, le message "Admis" sera affiché. Sinon, le message "Non admis" sera affiché.-->
<div class="form-row" id="divetudiant">

                           <div class="form-group col-md-4">
                                  <label class="control-label">Total : <?php echo $TOTAL; ?></label>
                                </div>
                          <div class="form-group col-md-4">
                                  <label class="control-label">Moyenne générale : <?php echo $MOYGENERAL; ?>/20</label>
                                </div>
                            <div class="form-group col-md-4">
                                  <label class="control-label"><?php if($MOYGENERAL >= 10){ echo "Admis"; }else{ echo "Non admis";} ?></label>
                                </div>
                                
                           </div> 
                                     
                </div>


<script src="js/jquery-331.min.js"></script>
<script src="js/bootstrap-337.min.js"></script>
<script type="js/formulaire.js"></script>
</body>
</html>